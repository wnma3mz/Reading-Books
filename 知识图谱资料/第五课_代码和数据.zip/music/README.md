## kg.course

## Jena_SPARQL.txt
此文件为Jena Fuseki演示时所有的SPARQL语句


## kg_music_triples.py
此文件为生成示例数据的Python程序 
此文件运行时可接受参数，参数为三元组数目 不加参数默认为1000个三元组
